# Build Jakarta Temple APK using only your Android phone

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml` that builds a debug APK in the cloud.

## Steps
1. In your Android browser, sign in to GitHub or create an account at https://github.com.
2. Create a new repository, e.g. `jakarta-temple-android`. A public repository is easiest for a first build; do not upload passwords, signing keys, or private information.
3. Upload the contents of this folder to the repository, keeping folder structure. The `.github/workflows/build-apk.yml` file must be included at the repository root under `.github/workflows/`.
4. Open the repository's **Actions** tab. If prompted, enable Actions.
5. Choose **Build Jakarta Temple APK** from the workflows list, tap **Run workflow**, and confirm.
6. Open the run that appears and wait until it completes successfully (green check mark).
7. Scroll to **Artifacts** and download `Jakarta-Temple-debug-APK`. GitHub downloads it as a ZIP file.
8. Open your Downloads folder, extract the artifact ZIP, and tap `app-debug.apk` to install it. If Android blocks installation, allow your browser or file manager to install unknown apps in Android Settings, then retry.

## Notes
- This produces a debug/test APK, not a Play Store release build.
- The project currently does not include a Gradle wrapper, so the workflow installs Gradle 8.7 in the cloud.
- The game imports Three.js from a CDN and needs internet access when running.
- The project has not been tested on a physical Android phone; if the workflow fails, open its log and share the error text so it can be fixed.
