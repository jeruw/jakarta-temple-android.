# Jakarta Temple — Android Studio project

This wraps the Jakarta Temple HTML/Three.js prototype in an Android WebView app. It is an Android project source bundle, **not a compiled APK**.

## Build an APK
1. Install Android Studio on a computer and let it install Android SDK 35 and a compatible JDK.
2. Extract this folder and open `JakartaTempleAndroid` in Android Studio.
3. Wait for Gradle sync to finish. If prompted, install missing Android Gradle Plugin/SDK components.
4. For a test APK, choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. When it finishes, use the notification's **locate** link. The APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Android phone and install it. You may need to allow installation from that file manager.

## Important
- Internet is required because the prototype imports Three.js from jsDelivr CDN.
- This is an early prototype and has not been built or tested on a physical Android device in this environment.
- For a public release, bundle Three.js locally, test performance on target phones, add app icon/splash screen, and sign a release APK/AAB.
